import { HttpClient } from '@angular/common/http';
import { AfterViewInit, Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { HackerNewsService } from './Service/hackerNewsService';
import { stories } from './Model/Hacker';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent implements AfterViewInit, OnInit{
  columns = [
    {text: 'Sr.No.', datafield: 'srno', width: 50},
		{text: 'Id', datafield: 'id', width: 100},
		{text: 'Title', datafield: 'title', width: 210},
    {text: 'Url', datafield: 'url' , width: 210}
  ];

  source:any;
  getAllTopStories:string='https://localhost:7216/HackerNews'
  public topStories:stories[]=[];

   constructor(private http : HttpClient,private hackerNewsService: HackerNewsService){
   } 
	 
  ngOnInit() {
    this.getTopStories();
  }

  getTopStories(){
    this.hackerNewsService.getTopStories()
    .subscribe(Response => {
      if(Response){  
        this.topStories=Response;
        this.source=new jqx.dataAdapter({localData:Response});
      }
      console.log(Response)
      console.log(this.source)
    });
  }

  ngAfterViewInit() {
	
  }
}
